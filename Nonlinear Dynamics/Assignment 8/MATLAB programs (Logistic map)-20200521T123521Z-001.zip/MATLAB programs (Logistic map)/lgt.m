function val=lgt(x)
global r
val=r.*x.*(1-x);